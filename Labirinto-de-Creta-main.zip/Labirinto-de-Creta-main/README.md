## Labirinto de Creta
#### Projeto de Algoritmos em Grafos - 2025.1
Link para playlist com os vídeos de explicação: [Labirinto de Creta](https://www.youtube.com/playlist?list=PLPQ1WkSoGf5wDQiaXZExMy1vgfCbygdPS)
#### Como executar?
- Rode o arquivo main.py em uma IDE ou editor de código
